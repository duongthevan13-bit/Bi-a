package com.example.billiardaim

import android.graphics.Bitmap
import android.graphics.PointF
import android.graphics.RectF
import org.opencv.android.Utils
import org.opencv.core.Core
import org.opencv.core.Mat
import org.opencv.core.MatOfFloat
import org.opencv.core.MatOfInt
import org.opencv.core.MatOfPoint
import org.opencv.core.MatOfPoint2f
import org.opencv.core.Rect
import org.opencv.core.Scalar
import org.opencv.core.Size
import org.opencv.imgproc.Imgproc
import kotlin.math.PI
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Giai đoạn 2: tìm mặt bàn (vải) và bi trắng.
 *  - Bàn: tự tìm màu vải chủ đạo (xanh lá/xanh dương đều được) bằng histogram Hue,
 *    lấy vùng liên thông lớn nhất, trả về hình chữ nhật bao.
 *  - Bi trắng: trong vùng bàn, lọc S thấp + V cao, chọn blob tròn nhất.
 * Ảnh được thu nhỏ còn ~640px chiều rộng để chạy nhanh, toạ độ trả về là toạ độ màn hình thật.
 */
class Detector {

    data class Result(
        val table: RectF?,
        val ball: PointF?,
        val ballRadius: Float,
        val ms: Long,
        val tableAreaPct: Int,
        val whiteBlobs: Int
    )

    // Có thể chỉnh nếu bi của game hơi ngả màu.
    var whiteSMax = 70.0
    var whiteVMin = 180.0

    fun process(bmp: Bitmap): Result {
        val t0 = System.currentTimeMillis()
        val mats = ArrayList<Mat>()
        fun <T : Mat> T.track(): T { mats.add(this); return this }
        try {
            val rgba = Mat().track()
            Utils.bitmapToMat(bmp, rgba)
            val scale = min(1.0, 640.0 / rgba.cols())
            val small = Mat().track()
            Imgproc.resize(rgba, small, Size(), scale, scale, Imgproc.INTER_AREA)
            val rgb = Mat().track()
            Imgproc.cvtColor(small, rgb, Imgproc.COLOR_RGBA2RGB)
            val hsv = Mat().track()
            Imgproc.cvtColor(rgb, hsv, Imgproc.COLOR_RGB2HSV)

            val tableRect = findTable(hsv, mats)
            val tablePct = tableRect?.let { (it.width * it.height * 100L / (hsv.cols() * hsv.rows())).toInt() } ?: 0
            if (tableRect == null) {
                return Result(null, null, 0f, System.currentTimeMillis() - t0, 0, 0)
            }

            val ballInfo = findCueBall(hsv, tableRect, mats)
            val inv = (1.0 / scale).toFloat()
            val table = RectF(
                tableRect.x * inv, tableRect.y * inv,
                (tableRect.x + tableRect.width) * inv, (tableRect.y + tableRect.height) * inv
            )
            val ball = ballInfo.first?.let { PointF(it.x * inv, it.y * inv) }
            return Result(table, ball, ballInfo.second * inv, System.currentTimeMillis() - t0, tablePct, ballInfo.third)
        } finally {
            mats.forEach { it.release() }
        }
    }

    /** Màu vải = đỉnh histogram Hue trong các điểm đủ bão hoà. */
    private fun findTable(hsv: Mat, mats: MutableList<Mat>): Rect? {
        val sat = Mat().also { mats.add(it) }
        Core.inRange(hsv, Scalar(0.0, 70.0, 50.0), Scalar(179.0, 255.0, 255.0), sat)
        val hist = Mat().also { mats.add(it) }
        Imgproc.calcHist(listOf(hsv), MatOfInt(0), sat, hist, MatOfInt(180), MatOfFloat(0f, 180f))
        val h = FloatArray(180)
        hist.get(0, 0, h)

        var bestHue = -1
        var bestSum = 0f
        for (c in 0 until 180) {            // cửa sổ 15 độ, vòng tròn
            var s = 0f
            for (d in -7..7) s += h[(c + d + 180) % 180]
            if (s > bestSum) { bestSum = s; bestHue = c }
        }
        if (bestHue < 0 || bestSum < hsv.cols() * hsv.rows() * 0.05f) return null

        val mask = hueMask(hsv, bestHue, 14, 60.0, 40.0, mats)
        val k = Imgproc.getStructuringElement(Imgproc.MORPH_RECT, Size(9.0, 9.0)).also { mats.add(it) }
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, k)
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, k)

        val contours = ArrayList<MatOfPoint>()
        val hier = Mat().also { mats.add(it) }
        Imgproc.findContours(mask, contours, hier, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)
        var best: MatOfPoint? = null
        var bestArea = 0.0
        for (c in contours) {
            val a = Imgproc.contourArea(c)
            if (a > bestArea) { bestArea = a; best = c }
        }
        val rect = best?.let { Imgproc.boundingRect(it) }
        contours.forEach { it.release() }
        if (rect == null || bestArea < hsv.cols() * hsv.rows() * 0.12) return null
        return rect
    }

    /** Trả về (tâm, bán kính, số blob trắng) theo toạ độ ảnh đã thu nhỏ. */
    private fun findCueBall(hsv: Mat, table: Rect, mats: MutableList<Mat>): Triple<PointF?, Float, Int> {
        val roi = hsv.submat(table).also { mats.add(it) }
        val mask = Mat().also { mats.add(it) }
        Core.inRange(roi, Scalar(0.0, 0.0, whiteVMin), Scalar(179.0, whiteSMax, 255.0), mask)
        val k = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0)).also { mats.add(it) }
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_OPEN, k)

        val contours = ArrayList<MatOfPoint>()
        val hier = Mat().also { mats.add(it) }
        Imgproc.findContours(mask, contours, hier, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE)

        val longSide = max(table.width, table.height).toDouble()
        val minR = longSide / 90.0
        val maxR = longSide / 22.0
        var bestScore = 0.0
        var center: PointF? = null
        var radius = 0f
        var blobs = 0

        for (c in contours) {
            val area = Imgproc.contourArea(c)
            val r = sqrt(area / PI)
            if (r < minR || r > maxR) continue
            blobs++
            val c2f = MatOfPoint2f(*c.toArray())
            val per = Imgproc.arcLength(c2f, true)
            c2f.release()
            if (per <= 0) continue
            val circ = 4 * PI * area / (per * per)
            val bb = Imgproc.boundingRect(c)
            val aspect = min(bb.width, bb.height).toDouble() / max(bb.width, bb.height)
            if (circ < 0.70 || aspect < 0.75) continue
            val score = circ * aspect
            if (score > bestScore) {
                bestScore = score
                center = PointF(table.x + bb.x + bb.width / 2f, table.y + bb.y + bb.height / 2f)
                radius = (bb.width + bb.height) / 4f
            }
        }
        contours.forEach { it.release() }
        return Triple(center, radius, blobs)
    }

    private fun hueMask(hsv: Mat, center: Int, tol: Int, sMin: Double, vMin: Double, mats: MutableList<Mat>): Mat {
        val out = Mat().also { mats.add(it) }
        val lo = center - tol
        val hi = center + tol
        when {
            lo < 0 -> {
                val a = Mat(); val b = Mat()
                Core.inRange(hsv, Scalar(0.0, sMin, vMin), Scalar(hi.toDouble(), 255.0, 255.0), a)
                Core.inRange(hsv, Scalar((180 + lo).toDouble(), sMin, vMin), Scalar(179.0, 255.0, 255.0), b)
                Core.bitwise_or(a, b, out); a.release(); b.release()
            }
            hi > 179 -> {
                val a = Mat(); val b = Mat()
                Core.inRange(hsv, Scalar(lo.toDouble(), sMin, vMin), Scalar(179.0, 255.0, 255.0), a)
                Core.inRange(hsv, Scalar(0.0, sMin, vMin), Scalar((hi - 180).toDouble(), 255.0, 255.0), b)
                Core.bitwise_or(a, b, out); a.release(); b.release()
            }
            else -> Core.inRange(hsv, Scalar(lo.toDouble(), sMin, vMin), Scalar(hi.toDouble(), 255.0, 255.0), out)
        }
        return out
    }
}
