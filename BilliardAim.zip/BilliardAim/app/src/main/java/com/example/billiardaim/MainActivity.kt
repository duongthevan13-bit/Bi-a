package com.example.billiardaim

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

/**
 * Màn hình điều khiển: xin lần lượt 3 quyền rồi khởi động CaptureService.
 *  1. SYSTEM_ALERT_WINDOW (vẽ đè lên ứng dụng khác)
 *  2. POST_NOTIFICATIONS (Android 13+, để hiện thông báo foreground)
 *  3. MediaProjection (người dùng phải đồng ý MỖI phiên, Android 14+ bắt buộc)
 */
class MainActivity : AppCompatActivity() {

    private lateinit var status: TextView
    private lateinit var startBtn: Button
    private lateinit var stopBtn: Button

    private val overlayPermLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                ensureNotificationPermissionThenCapture()
            } else {
                Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            }
        }

    private val notifPermLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) {
            // Dù được hay từ chối, vẫn thử tiếp: thông báo bị tắt không chặn foreground service.
            requestProjection()
        }

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val intent = Intent(this, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_START
                    putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(CaptureService.EXTRA_RESULT_DATA, result.data)
                }
                ContextCompat.startForegroundService(this, intent)
                setRunning(true)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
        }
        status = TextView(this).apply { textSize = 16f }
        startBtn = Button(this).apply {
            setText(R.string.btn_start)
            setOnClickListener { begin() }
        }
        stopBtn = Button(this).apply {
            setText(R.string.btn_stop)
            setOnClickListener {
                startService(Intent(this@MainActivity, CaptureService::class.java).apply {
                    action = CaptureService.ACTION_STOP
                })
                setRunning(false)
            }
        }
        root.addView(status)
        root.addView(startBtn)
        root.addView(stopBtn)
        setContentView(root)
        setRunning(false)
    }

    private fun setRunning(running: Boolean) {
        status.setText(if (running) R.string.status_running else R.string.status_idle)
        startBtn.isEnabled = !running
        stopBtn.isEnabled = running
    }

    private fun begin() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, R.string.need_overlay, Toast.LENGTH_LONG).show()
            overlayPermLauncher.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }
        ensureNotificationPermissionThenCapture()
    }

    private fun ensureNotificationPermissionThenCapture() {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            requestProjection()
        }
    }

    private fun requestProjection() {
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}
