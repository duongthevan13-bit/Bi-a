package com.example.billiardaim

import android.content.Context
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.os.Handler
import android.os.HandlerThread

/**
 * Thu khung hình màn hình bằng MediaProjection trên một luồng nền riêng
 * để không làm chậm luồng UI (giữ độ trễ thấp).
 *
 * onFrame được gọi trên luồng nền "capture". Bitmap trả về là bản sao,
 * bên nhận được phép giữ và tự recycle.
 */
class ScreenCapturer(
    private val context: Context,
    private val projection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val densityDpi: Int,
    private val onFrame: (Bitmap) -> Unit
) {
    private var thread: HandlerThread? = null
    private var reader: ImageReader? = null
    private var display: VirtualDisplay? = null

    @Volatile private var busy = false

    fun start() {
        val t = HandlerThread("capture").also { it.start() }
        thread = t
        val handler = Handler(t.looper)

        // Android 14+: phải registerCallback TRƯỚC khi createVirtualDisplay.
        projection.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stop() }
        }, handler)

        val r = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader = r
        display = projection.createVirtualDisplay(
            "billiard-capture", width, height, densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, handler
        )

        r.setOnImageAvailableListener({ ir ->
            val image = ir.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                if (busy) return@setOnImageAvailableListener   // bỏ khung nếu đang xử lý khung trước
                busy = true
                val plane = image.planes[0]
                val rowPadding = plane.rowStride - plane.pixelStride * width
                val raw = Bitmap.createBitmap(
                    width + rowPadding / plane.pixelStride, height, Bitmap.Config.ARGB_8888
                )
                raw.copyPixelsFromBuffer(plane.buffer)
                val frame = Bitmap.createBitmap(raw, 0, 0, width, height)
                raw.recycle()
                try { onFrame(frame) } finally { busy = false }
            } finally {
                image.close()
            }
        }, handler)
    }

    fun stop() {
        display?.release(); display = null
        reader?.setOnImageAvailableListener(null, null)
        reader?.close(); reader = null
        thread?.quitSafely(); thread = null
    }
}
