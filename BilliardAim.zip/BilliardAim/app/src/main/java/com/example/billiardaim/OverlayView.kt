package com.example.billiardaim

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PointF
import android.graphics.RectF
import android.view.View
import kotlin.math.max

/**
 * Lớp Canvas trong suốt vẽ đè lên màn hình.
 * Giai đoạn 1: chỉ vẽ khung gợi ý để kiểm tra overlay hoạt động.
 * Giai đoạn 2-3 sẽ dùng setTable / setCueBall / setAimPath để vẽ thật.
 *
 * Lưu ý quan trọng: MediaProjection chụp cả overlay này. Vì vậy màu đường kẻ
 * (xanh lục/cam) cố ý khác dải HSV của bi trắng để bộ phát hiện không nhận nhầm.
 */
class OverlayView(context: Context) : View(context) {

    private val density = resources.displayMetrics.density

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF6D00")
        style = Paint.Style.STROKE
        strokeWidth = 2.5f * density / 2f   // ~2-3 px theo đặc tả
        strokeCap = Paint.Cap.ROUND
    }
    private val tablePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#00E5FF")
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF6D00")
        textSize = 14f * density
    }

    private val ballPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF00FF")   // tím hồng: khác dải trắng và màu vải
        style = Paint.Style.STROKE
        strokeWidth = 3f
    }

    @Volatile private var tableRect: RectF? = null
    @Volatile private var cueBall: PointF? = null
    @Volatile private var cueRadius = 0f
    @Volatile private var status = "Overlay OK"
    private var path: List<PointF> = emptyList()

    fun setTable(rect: RectF?) { tableRect = rect; postInvalidate() }
    fun setCueBall(center: PointF?, radius: Float = 0f) { cueBall = center; cueRadius = radius; postInvalidate() }
    fun setStatus(text: String) { status = text; postInvalidate() }
    fun setAimPath(points: List<PointF>) { path = points; postInvalidate() }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        tableRect?.let { canvas.drawRect(it, tablePaint) }

        if (path.size >= 2) {
            for (i in 0 until path.size - 1) {
                canvas.drawLine(path[i].x, path[i].y, path[i + 1].x, path[i + 1].y, linePaint)
            }
        }

        cueBall?.let { canvas.drawCircle(it.x, it.y, max(cueRadius, 8f) + 4f, ballPaint) }

        canvas.drawText(status, 24f * density, 48f * density, textPaint)
    }
}
